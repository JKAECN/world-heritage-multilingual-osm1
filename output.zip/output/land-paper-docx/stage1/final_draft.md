# Urban Land-Use Functions and Multilingual Digital Visibility in World Heritage Cities: A 59-City Grid-Based Analysis

**Abstract:** Digital maps are now the primary interface between World Heritage cities and international visitors, yet we know little about how the multilingual content of these maps is distributed within cities and what urban functions shape it. We measure *multilingual digital visibility*—the share of named points of interest (POIs) whose OpenStreetMap (OSM) name tags contain more than one language—in 59 World Heritage cities across 36 countries, using 50,506 regular 500 m grid cells within 8 km of each heritage core. The main analysis covers 15,020 grids with at least five named POIs (552,553 named POIs in total) and applies quasi-binomial generalized linear models with city fixed effects and a natural cubic spline for distance to the heritage core. Multilingual digital visibility is strongly patterned: predicted visibility declines from about 0.18 at the heritage core to 0.07 at the 8 km boundary; visitor-oriented functional intensity is positively associated with multilingual visibility; commercial/retail and residential land-use shares are positively associated with multilingual visibility while institutional land is negatively associated; and these relationships are robust to alternative multilingual definitions, POI-count thresholds, and the exclusion of cities with poor land-use coverage, but heterogeneous across macro-regions—the pooled visitor-intensity effect is carried by Latin American cities. Two definitional findings qualify the interpretation: under a strict definition (at least two explicit language tags), the land-use coefficients reverse sign, and a two-part decomposition shows that visitor intensity operates on the extensive margin (whether a grid contains any multilingual POI) rather than on the intensity of multilingual naming. Data-quality diagnostics reveal severe zero inflation (54.8% of all grids contain no named POI; 48.7% of main-sample grids have zero multilingual visibility) and city-to-city variation in explicit language-tag coverage spanning two orders of magnitude, which we report transparently and address through robustness analysis. Throughout, our measures describe the *digital* linguistic landscape of OSM, not physical street signage.

**Keywords:** multilingual digital visibility; linguistic landscape; OpenStreetMap; volunteered geographic information; World Heritage cities; land use; urban functions; 500 m grid; quasi-binomial GLM

---

## 1. Introduction

Digital mapping platforms have become the primary interface between historic cities and international visitors. When a traveler arrives in an unfamiliar city, the practical question of "where can I eat, and will I be able to read the name?" is increasingly answered by a screen rather than by a street sign. The languages attached to place names in digital maps therefore constitute a form of *digital linguistic landscape*: a distributed, crowd-sourced layer of multilingual representation that precedes and accompanies physical movement through the city. In World Heritage cities—where tourism pressure, heritage conservation, and multilingual encounter are most intense—this layer is likely to be both dense and unevenly distributed.

The classical linguistic-landscape tradition studies exactly this kind of question, but in the physical world. Landry and Bourhis [1] defined the linguistic landscape as the language of public signs, advertising billboards, street names, place names, commercial shop signs, and public building signs, and identified its informational and symbolic functions. Subsequent work established that multilingual signage is a symbolic construction of public space shaped by rational considerations, self-presentation, and power relations [2], and developed geosemiotic tools for reading language in the material world [3]. Detailed case studies—most famously Backhaus's census of 2,444 signs across 28 Tokyo districts [4]—showed that multilingual signage varies sharply *within* cities, often tracking commercial and tourist zones. Yet this tradition relies on field observation of physical signage: samples are small, geographically bounded, and hard to compare across cities and languages.

A parallel literature in digital geography has begun to ask analogous questions about the *digital* world. Graham and Zook's study of the "geolinguistic contours of the web" showed that language visibility online is unevenly distributed [5], and subsequent work on platform mapping demonstrated that digital maps do not merely represent urban space but actively produce visibility and territorial inequality [6]. Meanwhile, volunteered geographic information (VGI) [7,8] has matured into a serious research infrastructure: OpenStreetMap (OSM) now provides global, freely licensed coverage of named POIs—including machine-readable `name:<language>` tags that record, for each place, which languages its name is available in. This makes it possible, for the first time, to measure the multilingual content of the digital map itself, at high spatial resolution, across many cities simultaneously. POI data have likewise become a standard proxy for urban land-use functions [9,10].

What is missing is a systematic, within-city, cross-city quantification that connects these three literatures. Existing studies of multilingual visibility are either single-city case studies of physical signage or global-scale analyses of web content; nobody has measured how multilingual *digital* visibility is distributed inside World Heritage cities, or tested whether that distribution follows the functional logic of the city—its commercial streets, residential fabric, tourist zones, and distance from the heritage core. This paper addresses that gap. We ask: how is multilingual digital visibility distributed within World Heritage cities, and is this distribution systematically shaped by urban land-use functions, visitor-oriented functional intensity, and distance to the World Heritage core?

We answer this question with a grid-based design covering 59 World Heritage cities in 36 countries across Europe, Asia/MENA, and Latin America. Within each city we construct 500 m grid cells over an 8 km radius around the UNESCO heritage coordinate, attach OSM-derived measures of named POIs, multilingual naming, visitor-oriented facilities, and land-use composition, and estimate quasi-binomial GLMs with city fixed effects and a natural cubic spline for heritage distance. The design yields three substantive hypotheses: **H1**, commercial/retail and leisure-oriented spaces exhibit higher multilingual digital visibility than predominantly residential spaces; **H2**, controlling for overall POI density and city differences, visitor-oriented functional intensity is positively associated with multilingual visibility; and **H3**, multilingual visibility varies nonlinearly with distance from the heritage core. A fourth question—**RQ1**—asks whether these relationships are stable across cities and macro-regions.

The paper makes four contributions. First, it provides the first large-sample, grid-resolved measurement of multilingual digital visibility in World Heritage cities, moving beyond case-study designs. Second, it tests, in a common specification, whether digital multilingual visibility follows the functional structure of the city—land use, visitor orientation, and heritage proximity—rather than being randomly distributed. Third, it documents the data-quality structure of crowd-sourced linguistic data (zero inflation, coverage heterogeneity) and shows how robustness analysis can discipline inference from such data. Fourth, it is deliberately scoped: by measuring visibility without modelling representational mismatch, it establishes a clean empirical baseline for a companion study of functional–representational relations.

One terminological point must be stated at the outset and is respected throughout: our measures describe the **multilingual digital visibility of places in OpenStreetMap**, inferred from `name`, `name:<language>`, and `int_name` tags. They are not counts of languages on physical street signs. Digital visibility is shaped by mapping practices, contributor communities, and platform conventions as much as by the linguistic realities of the street; we return to this distinction in the Discussion.

The remainder of the paper is organized as follows. Section 2 describes the data, measures, grid design, and model specification. Section 3 reports data quality, descriptive patterns, and model results, including the robustness suite. Section 4 discusses the findings in relation to the hypotheses, the regional heterogeneity, definitional sensitivity, and the limits of OSM-based inference. Section 5 concludes.

## 2. Materials and Methods

### 2.1. Study design and sample

The study sample was defined as 59 World Heritage cities drawn from the UNESCO World Heritage List, spanning three macro-regions (Europe, Asia/MENA, Latin America) and selected to cover diverse linguistic, institutional, and tourism contexts (Table 1, Figure 1A). Cities were identified from the official World Heritage List dataset (1,273 properties, cleaned), and each city's heritage core coordinate was pre-matched to its inscribed property.

For each city we defined a study area as an 8 km radius circle around the UNESCO heritage coordinate—a scale that comfortably contains the historic core and its immediate urban surroundings, where heritage-related functional gradients are strongest, while remaining computationally feasible for OSM extraction. The 8 km radius is also large enough to include substantial non-tourist urban fabric, which is essential for identifying within-city contrasts.

### 2.2. Data sources

**UNESCO World Heritage List.** Heritage property names, countries, and coordinates come from the official World Heritage List data, pre-matched to the master table of World Heritage cities. The full cleaned list (1,273 properties) is retained for provenance and cross-checking.

**OpenStreetMap.** All POI and land-use data were retrieved from OSM through the Overpass API on 17 October 2026 (data access date recorded per grid). OSM data are licensed under the Open Database License (ODbL); © OpenStreetMap contributors. Three extraction layers were used: (i) named POIs (any element carrying a `name` tag), with their `name:<language>`, `int_name`, and functional tags; (ii) visitor-oriented POIs (`tourism=*`, `historic=*`, restaurants, cafés, bars, theatres, arts centres, marketplaces, souvenir and gift shops, travel agencies, stations, marinas, and related tags); and (iii) `landuse=*` closed-way polygons. Because OSM coverage and tagging conventions vary across the world [11,12], we treat coverage diagnostics as first-class outputs rather than assumptions (Section 3.1).

### 2.3. Measures

Table 2 defines all variables. In brief, for each grid cell we computed:

**Named POIs.** The denominator of all visibility measures: POIs carrying a `name` tag within the cell.

**Multilingual digital visibility (primary definition).** A named POI counts as multilingual if its default name is accompanied by at least one *distinct* explicit language name (e.g., `name:en` differing from `name`), or if it carries at least two explicit language tags (`name:xx` with different languages). Grid-level visibility is the share of multilingual POIs among named POIs:

$$MV_{ij} = \frac{n_{multilingual,ij}}{n_{named,ij}}$$

**Multilingual visibility (strict definition).** A named POI counts as multilingual only if it carries at least two explicit language tags. This stricter measure is used in robustness analysis because it does not rely on the (convention-dependent) comparison between the default name and a translated name.

**English visibility.** Share of named POIs with an English name tag (`name:en` or an `int_name`), reported as an auxiliary outcome given the global role of English [13].

**Auxiliary language measures.** International-name visibility (share with `int_name`), mean number of explicit languages per POI, language richness (number of distinct languages present), and language entropy of the language distribution.

**Visitor-oriented functional intensity.** Count and density (per km²) of visitor-oriented POIs (Section 2.2). Density is the main-analysis measure because it is interpretable as visitor-oriented functional intensity and is comparable across grids of unequal mapped area.

**Land-use functions.** Shares of cell area in ten OSM land-use classes: residential, commercial/retail, industrial, institutional, recreation/green, green/natural, agriculture, transportation, construction, and other. Two features of these variables matter for interpretation. First, they are *shares*, so coefficients are per unit share (a 0.10 increase equals ten percentage points of cell area). Second, OSM land-use mapping is incomplete and uneven across cities; we therefore retain `landuse_mapped_coverage`—the share of cell area covered by any mapped land-use polygon—as an explicit data-quality diagnostic.

**Heritage distance.** Euclidean distance from the cell centroid to the UNESCO heritage coordinate, in metres and kilometres.

### 2.4. Grid construction and analysis sample

Within each 8 km study circle we generated a regular square lattice of 500 m cells, intersected it with the study circle, and retained all intersecting cells. This produced 50,506 cells (856 per city; 858 in Córdoba, where two additional tangent cells intersect the circle). Cell geometry was reconstructed exactly from the build pipeline for mapping (Section 3.7, Figure 4). The analysis unit is the cell; the effective sample is therefore "59 cities × ~856 grids", not 59 city averages.

The main analysis sample consists of cells with at least five named POIs (n = 15,020). This threshold follows the data rather than convenience: 54.8% of all cells contain no named POI, and cells with one or two named POIs produce structurally unstable proportions (a single multilingual POI yields visibility of 0.5 or 1.0). We retain the full 50,506-cell set for descriptive and coverage analysis, and we examine thresholds of 5, 10, and 20 named POIs in the robustness suite. Zero inflation is not a nuisance to be hidden: 48.7% of main-sample cells have zero multilingual visibility under the primary definition (62.1% under the strict definition), and the median visibility is 0.013 against a mean of 0.106. The quasi-binomial model with city fixed effects is our primary response to this structure; a two-part decomposition is reported as an additional check.

### 2.5. Model specification

For cell *i* in city *j*, let $p_{ij}$ be the probability that a named POI is multilingual. We estimate:

$$\text{logit}(p_{ij}) = \beta_0 + \beta_1\,\text{VisitorIntensity}_{ij} + \beta_2\,\text{Commercial}_{ij} + \beta_3\,\text{Residential}_{ij} + \beta_4\,\text{Recreation}_{ij} + \beta_5\,\text{Institutional}_{ij} + \beta_6\,\text{Transportation}_{ij} + \beta_7\,\text{POIDensity}_{ij} + f(\text{Distance}_{ij}) + \alpha_j$$

with the outcome modelled as binomial counts $cbind(n_{multilingual},\,n_{named} - n_{multilingual})$, visitor intensity and POI density entering as $\log(1+x)$, distance through a natural cubic spline with four degrees of freedom (motivated by the expectation of a nonlinear core–periphery gradient rather than a monotone line), and $\alpha_j$ a full set of city fixed effects that absorb all stable city-level differences—including language policy, mapping conventions, and overall tagging intensity. Because residual dispersion substantially exceeds the binomial assumption (Pearson dispersion ≈ 4.18), we use quasi-binomial estimation, i.e., quasi-likelihood with the binomial mean–variance relation and an estimated dispersion parameter [14,15], so that standard errors remain valid under overdispersion [16]. Coefficients are log-odds per unit of the predictor; to make effects interpretable on the probability scale we report average marginal predictions (Figures 2 and 3) with city-level bootstrap confidence intervals (1,000 draws).

Two auxiliary models use the identical specification: an English-visibility outcome, and an interaction between visitor intensity and commercial/retail share (reported in the Supplementary Materials). The estimation was first implemented in R (`glm`, family `quasibinomial`) and then independently re-implemented in Python (statsmodels GLM with a manually computed Pearson dispersion, patsy natural spline basis); the two implementations agree on all core coefficients to the third decimal (e.g., visitor intensity 0.0540 in R vs. 0.0556 in Python, with dispersion 4.176 vs. 4.178), and all reported results come from the cross-validated Python implementation.

### 2.6. Robustness analysis

Five robustness groups are reported (Table 5): **(R1) definition**—the strict multilingual definition (at least two explicit language tags); **(R2) POI thresholds**—main-sample grids re-estimated at ≥10 and ≥20 named POIs; **(R3) land-use coverage**—subsamples with `landuse_mapped_coverage` ≥ 0.25 and ≥ 0.50, thresholds chosen from the observed coverage distribution; **(R4) regional heterogeneity**—separate estimation for Europe, Asia/MENA, and Latin America to test whether pooled results are carried by one region; and **(R5) structural checks**—a two-part decomposition (binomial model for any-multilingual vs. share among positive cells) and re-estimation after dropping the 15 cities whose mean land-use coverage is below 0.10.

## 3. Results

### 3.1. Data quality: what the crowd-sourced landscape actually contains

Table S1 (Supplementary Materials) reports per-city quality diagnostics. Three findings structure everything that follows.

First, **named-POI density is the binding constraint**. Across all 50,506 cells, 27,666 (54.8%) contain no named POI; 70.3% contain fewer than five; 86.1% fewer than twenty. POI-rich cells concentrate in city centres, and the ≥5 threshold retains 15,020 cells with a mean of 36.8 named POIs (median 18). The main-sample visibility distribution is extremely right-skewed (mean 0.106, median 0.013, maximum 1.0).

Second, **explicit language-tag coverage varies by two orders of magnitude across cities**—from 0.5% of named POIs in Salvador de Bahia to 87.8% in Lijiang. This is a mapping-convention effect as much as a linguistic one, and it means that city-level visibility differences must be read as differences in the *digital record*, not as direct measurements of linguistic practice. The city fixed effects absorb the stable component of this variation; the definitional robustness check (R1) probes its consequence.

Third, **OSM land-use coverage is incomplete and city-specific**. Across all cells, 40.7% have zero mapped land use; the median coverage is 0.036 and the mean 0.246. Within the main sample the mean coverage rises to 0.371, but 15 cities average below 0.10 (e.g., Venice 0.075, Dubrovnik 0.032, Vigan 0.004, Pingyao 0.085, Zacatecas 0.006), while others exceed 0.65 (Sighișoara 0.643, Arequipa 0.653, Warsaw 0.671). R3 and R5(b) test whether results survive these coverage differences.

### 3.2. Descriptive patterns

Table 3 reports grid-level descriptive statistics for the main sample; Table S2 reports city-level values. City-level multilingual visibility (POI-weighted) averages 0.136 across the 59 cities, but the regional means differ sharply: Asia/MENA 0.303, Europe 0.066, Latin America 0.033. The extremes are instructive: Ayutthaya (0.755), Macao (0.660), Pingyao (0.614), Algiers (0.496), Tunis (0.440) and Istanbul (0.422) at the top; Salvador de Bahia (0.003), Córdoba (0.007), Oaxaca (0.008), Ouro Preto (0.011) and Zacatecas (0.012) at the bottom. English visibility shows a different ordering (Ayutthaya 0.796, Pingyao 0.614, Macao 0.434, Lijiang 0.349 and Nara 0.302 at the top; Salvador de Bahia 0.003, Córdoba 0.005, Zacatecas 0.006 and Santiago de Compostela 0.006 at the bottom): Istanbul's multilingual visibility is high (0.422) while its English visibility is low (0.041), confirming that multilingual digital visibility and English dominance are distinct phenomena. Visitor-oriented POI density averages 44.2 per km² in the main sample (median 12.0), ranging from zero to 2,416.

### 3.3. Land-use functions (H1)

Table 4 reports the main model (N = 15,020 cells; 59 cities; Pearson dispersion 4.178). Commercial/retail share is positively associated with multilingual visibility (β = 0.187, p = 0.031), consistent with H1. However, the coefficient for residential share is positive *and larger* (β = 0.306, p < 0.001), and institutional share is strongly negative (β = −1.900, p = 0.007); recreation/green (β = −0.298, p = 0.563) and transportation (β = 0.151, p = 0.627) are not distinguishable from zero. Overall POI density is negative (β = −0.082, p < 0.001): holding land-use composition constant, denser POI environments are *less* multilingual, which is consistent with the interpretation that the land-use coefficients capture functional mix rather than sheer commercial intensity.

Figure 2A translates the model into predicted probabilities by the dominant land-use type of each cell. The five types span a narrow range (0.095 for institutional-dominant to 0.113 for transportation-dominant cells) with broadly overlapping confidence intervals; Figure 2B shows the model-implied gradient as the focal share rises from 0 to 0.6: visibility increases modestly for commercial/retail (0.103 → 0.112) and residential (0.099 → 0.113) shares, is flat for transportation, declines slightly for recreation/green (0.104 → 0.091), and declines strongly for institutional share (0.104 → 0.042). The substantive reading of H1 is therefore nuanced: commercial space is positively associated with multilingual visibility, but it is not uniquely so—residential fabric shows an equally strong positive association, and the sharpest contrast is institutional versus everything else. We return to the interpretation in Section 4.1.

### 3.4. Visitor-oriented functional intensity (H2)

Visitor-oriented POI density is positively and significantly associated with multilingual visibility (β = 0.056, p < 0.001 on the log1p scale; H2 supported). The interaction with commercial/retail share is null (β = −0.007, p = 0.899; Table S3), so the visitor effect does not operate specifically through retail space. In the English-visibility model, the visitor coefficient is four times larger (β = 0.231, p < 0.001; Table S4), indicating that visitor-oriented environments are disproportionately *English-named* rather than multilingual in general.

### 3.5. Distance to the heritage core (H3)

The distance spline is jointly highly significant (Wald χ²(4) = 12,714.5, p < 0.001), rejecting a linear distance effect in favour of the specified nonlinear form. Figure 3 shows the predicted gradient: holding visitor intensity, POI density, and land-use composition at sample means and averaging over cities, predicted visibility falls from 0.178 at the heritage core to 0.069 at 8 km—a decline of about 60% across the study radius. The observed POI-weighted band means (diamonds) decline more gently (0.127 in the 0–1 km band to 0.084 beyond 7 km), because near-core cells also carry higher visitor intensity and POI density, which partly offset the pure distance effect; the controlled gradient is therefore steeper than the raw one. H3 is supported: multilingual digital visibility concentrates around heritage cores in a nonlinear fashion.

### 3.6. Robustness (Table 5)

**R1—definition.** Under the strict definition, visitor intensity remains positive and roughly doubles in magnitude (β = 0.102, p < 0.001), but the land-use signs reverse: commercial becomes negative (β = −0.355, p = 0.002) and residential strongly negative (β = −0.485, p < 0.001), while transportation turns positive (β = 0.869, p < 0.001). The strict measure—requiring two explicit language tags—is concentrated in transport hubs and other infrastructural nodes rather than in retail and residential fabric. The distance effect is unchanged in sign and significance.

**R2—POI thresholds.** At ≥10 named POIs the main coefficients are essentially unchanged. At ≥20, residential (β = 0.292, p < 0.001) and institutional (β = −2.058, p = 0.021) remain significant, but the visitor-intensity coefficient attenuates and loses significance (β = 0.030, p = 0.222), and commercial becomes marginal. The visitor association is thus partly carried by cells with moderate POI counts; the land-use and distance results are stable.

**R3—land-use coverage.** In the high-coverage subsamples the visitor and commercial coefficients flip sign (e.g., ≥0.50 coverage: β = −0.082 and −0.733, both p < 0.01). This is a selection effect, not a contradiction: cells with fully mapped land use are disproportionately peripheral, suburban cells where mapped commercial land (retail parks, edge-of-city commerce) carries little multilingual naming, unlike the historic-core retail that dominates the full sample. Coverage therefore cannot be treated as missing-at-random, and the pooled estimates should be read as describing the study radius as a whole.

**R4—regional heterogeneity.** The pooled visitor effect is carried almost entirely by Latin America (β = 0.476, p < 0.001); it is null in Europe (β = −0.010) and Asia/MENA (β = 0.000). Land-use patterns also differ: residential is positive in Europe (β = 0.511) but negative in Asia/MENA (β = −0.272); commercial is positive in Asia/MENA (β = 0.527) and negative in Latin America (β = −2.199); institutional is strongly negative in Europe (β = −3.986) but null in Asia/MENA. The distance spline remains significant in all three regions. The main conclusions are thus not driven by European cities alone—but neither are they uniform: RQ1 must be answered with an explicit regional qualification.

**R5—structural checks.** Among cells that contain at least one multilingual POI, the visitor-intensity coefficient vanishes (β = −0.004, p = 0.956) while the land-use coefficients persist. Visitor orientation therefore predicts *whether* a cell hosts any multilingual naming (the extensive margin), not the intensity of multilingual naming within it—a direct response to the zero-inflation structure documented in Section 3.1. Dropping the 15 low-coverage cities leaves all main coefficients significant and stable (visitor β = 0.048, p = 0.003; commercial β = 0.198, p = 0.026; residential β = 0.311, p < 0.001; institutional β = −1.894, p = 0.004), so the pooled results are not an artifact of poorly mapped cities.

### 3.7. The spatial face of the data

Figure 4 maps multilingual digital visibility for six representative cities. The contrast between the tourist-historic fabric and the surrounding city is visible to the naked eye: Istanbul's multilingual core hugs the historic peninsula; Kyoto's visibility concentrates in the eastern old town and the station area; Macao shows near-continuous multilingual naming across the peninsula; Cusco's visibility clusters around the Plaza de Armas and San Blas; Vienna and Salvador de Bahia are almost uniformly pale. The maps also show the grey mask of cells without named POIs, which is itself part of the data-quality story.

## 4. Discussion

### 4.1. Land-use functions: a more complicated story than "commercial = multilingual"

H1 anticipated that commercial/retail and leisure spaces would outperform residential spaces. The data support the commercial association but not the contrast: residential fabric is at least as strongly associated with multilingual visibility as commercial space. Three interpretations are plausible and not mutually exclusive. First, in historic cities the "residential" land-use class in OSM covers dense mixed-use old-town fabric where shops, cafés, and guesthouses are physically embedded in housing; the class boundary between residential and commercial is blurred exactly where tourist multilingualism is produced. Second, OSM land-use polygons are mapped by local contributors with heterogeneous conventions—what is tagged residential in one city may be tagged commercial in another—so the coefficient partly measures mapping practice. Third, the negative institutional coefficient (the strongest and most stable land-use effect) suggests that what really depresses multilingual visibility is administrative/institutional space, not residential life *per se*. Under the strict definition the pattern changes again (R1), which warns against reading any single land-use coefficient as a property of the physical city. The robust conclusion is narrower but cleaner: multilingual digital visibility is not randomly scattered across the urban fabric; it tracks specific functional mixes, with institutional space as a consistent negative pole and transport nodes as a positive pole under the strict definition.

### 4.2. Heritage cores and the geography of digital visibility

The nonlinear distance gradient (H3) is the most structurally robust finding in the paper: significant under every specification, definition, threshold, and region. Predicted visibility at the heritage core is roughly 2.5 times the visibility at the 8 km boundary. This is consistent with the long-standing observation that tourism development in heritage cities follows a "vicious circle" of functional concentration in the core [17], and with the Historic Urban Landscape perspective that heritage value is embedded in the whole urban fabric rather than confined to the core [18]—our results quantify the digital shadow of that concentration. Overtourism research has documented how touristification reshapes local commerce [19,20]; our measures show that the same process reshapes the *digital* representation of the city, with the core's multilingual layer serving an audience of international visitors while peripheral areas remain effectively monolingual in the digital record.

### 4.3. Visitor orientation: an extensive-margin effect with strong regional structure

H2 is supported in the pooled sample, but the robustness suite complicates it in two productive ways. The two-part decomposition shows that visitor intensity predicts whether any multilingual POI exists in a cell, not how multilingual a cell is once it has any—an extensive-margin signature that mirrors the zero-inflated data structure and suggests that visitor-oriented functions introduce multilingual naming into otherwise unmapped or monolingual cells rather than deepening it everywhere. And the regional models show the pooled effect is carried by Latin American cities, where within-city tourist gradients are steep, while Europe and Asia/MENA show no within-city visitor effect once city fixed effects absorb between-city differences. This is exactly the kind of instability RQ1 was designed to detect: the visitor association is real but geographically structured, and future work should treat it as a regional hypothesis rather than a universal law.

### 4.4. Definitional sensitivity: what "multilingual" means in OSM

The primary and strict definitions agree on the distance effect but disagree on land use. The primary definition (default name plus a distinct explicit language name, or ≥2 language tags) is sensitive to local conventions about whether translated names are stored as `name:xx` or merged into the default name; the strict definition is conservative. The sign reversal between them—commercial positive under primary, negative under strict; transportation null under primary, strongly positive under strict—indicates that different kinds of multilingualism coexist: name-translation practices in retail and hospitality (captured by the primary definition) versus genuine multi-script/multi-language tagging at transport hubs (captured only by the strict definition). English visibility, finally, behaves differently again, confirming Crystal's point about the distinct global role of English [13] at the level of digital place names: visitor environments are English-heavy, but multilingual visibility is not reducible to English.

### 4.5. What OSM can and cannot tell us

Three limitations deserve emphasis. (i) *Coverage and conventions.* OSM's completeness and tagging practices vary enormously across cities [11,12]; we handle the stable component with city fixed effects and the unstable component with definitional and coverage robustness checks, but residual convention effects certainly remain. (ii) *Zero inflation.* With half of all cells empty of named POIs, the sample is a sample of the mapped city, not the whole city; our ≥5 threshold makes proportions estimable but shrinks coverage of peripheral areas, which is one reason the controlled distance gradient is steeper than the raw one. (iii) *Digital, not physical.* Most importantly, our measures describe a digital artifact. Multilingual digital visibility is shaped by who maps, in which language, and for whom; it correlates with—but is not the same as—the multilingualism of streets and shopfronts. Claims about digital visibility are well supported by these data; claims about physical linguistic landscapes would require field validation. We regard the digital measure as interesting in its own right: for a growing share of visitors, the map *is* the first encounter with the city's linguistic environment.

### 4.6. Relation to the companion study

This paper deliberately stops at measuring and explaining the distribution of multilingual digital visibility. Whether the geography of multilingual visibility matches the geography of visitor-facing functions—and what a functional–representational mismatch would mean for heritage governance—is the subject of a companion analysis. Keeping the two questions separate protects both: the baseline established here is clean of mismatch constructs, and the mismatch analysis inherits a validated measurement foundation.

## 5. Conclusions

We constructed the first grid-resolved, multi-city measurement of multilingual digital visibility in World Heritage cities, covering 59 cities, 50,506 cells of 500 m, and 552,553 named POIs in the analysis sample. Multilingual digital visibility is strongly structured within cities: it declines nonlinearly from heritage cores, is positively associated with visitor-oriented functional intensity and with commercial and residential land-use shares, and is depressed by institutional land. These patterns survive alternative definitions, POI thresholds, and coverage-based subsampling, but they are regionally heterogeneous—the visitor-intensity effect is carried by Latin American cities—and definition-sensitive at the level of land use. Two methodological lessons generalize beyond this study: crowd-sourced linguistic data require explicit zero-inflation and coverage diagnostics before modelling, and "multilingual" is an operational construct whose definition materially changes substantive conclusions.

For heritage cities, the results carry a practical implication. The digital layer through which most international visitors now encounter the city is highly uneven: a multilingual core, an English-inflected visitor economy, and a largely monolingual digital periphery. Managers and platform contributors who care about the multilingual representativeness of the digital city have a measurable target—and, for the first time, a reproducible baseline against which to track it.

**Author Contributions:** Conceptualization, methodology, formal analysis, investigation, data curation, visualization, and writing were carried out by the research team as an integrated effort.

**Funding:** This research received no external funding.

**Data Availability Statement:** The analysis dataset (50,506 grid cells with all derived measures) and the reproducible build and analysis scripts are available from the authors on request. Underlying OpenStreetMap data are publicly available via the Overpass API under the ODbL (© OpenStreetMap contributors); UNESCO World Heritage List data are publicly available from the UNESCO World Heritage Centre. Data access date: 17 October 2026.

**Acknowledgments:** We thank the OpenStreetMap contributor community whose work makes studies of this kind possible.

**Conflicts of Interest:** The authors declare no conflicts of interest.

---

## References

[1] Landry, R.; Bourhis, R.Y. Linguistic Landscape and Ethnolinguistic Vitality: An Empirical Study. *Journal of Language and Social Psychology* **1997**, *16*, 23–49. https://doi.org/10.1177/0261927X970161002

[2] Ben-Rafael, E.; Shohamy, E.; Hasan Amara, M.; Trumper-Hecht, N. Linguistic Landscape as Symbolic Construction of the Public Space: The Case of Israel. *International Journal of Multilingualism* **2006**, *3*, 7–30. https://doi.org/10.1080/14790710608668383

[3] Scollon, R.; Scollon, S.W. *Discourses in Place: Language in the Material World*; Routledge: London, UK, 2003. https://doi.org/10.4324/9780203422724

[4] Backhaus, P. *Linguistic Landscapes: A Comparative Study of Urban Multilingualism in Tokyo*; Multilingual Matters: Clevedon, UK, 2007.

[5] Graham, M.; Zook, M. Augmented Realities and Uneven Geographies: Exploring the Geolinguistic Contours of the Web. *Environment and Planning A: Economy and Space* **2013**, *45*, 77–99. https://doi.org/10.1068/a44674

[6] Luque-Ayala, A.; Maia, F.N. Digital Territories: Google Maps as a Political Technique in the Re-making of Urban Informality. *Environment and Planning D: Society and Space* **2019**, *37*, 449–467. https://doi.org/10.1177/0263775818766069

[7] Goodchild, M.F. Citizens as Sensors: The World of Volunteered Geography. *GeoJournal* **2007**, *69*, 211–221. https://doi.org/10.1007/s10708-007-9111-y

[8] Haklay, M.; Weber, P. OpenStreetMap: User-Generated Street Maps. *IEEE Pervasive Computing* **2008**, *7*, 12–18. https://doi.org/10.1109/MPRV.2008.80

[9] Yuan, J.; Zheng, Y.; Xie, X. Discovering Regions of Different Functions in a City Using Human Mobility and POIs. In *Proceedings of the 18th ACM SIGKDD International Conference on Knowledge Discovery and Data Mining*, Beijing, China, 12–16 August 2012; pp. 186–194. https://doi.org/10.1145/2339530.2339561

[10] Andrade, R.; Alves, A.; Bento, C. POI Mining for Land Use Classification: A Case Study. *ISPRS International Journal of Geo-Information* **2020**, *9*, 493. https://doi.org/10.3390/ijgi9090493

[11] Elwood, S.; Goodchild, M.F.; Sui, D.Z. Researching Volunteered Geographic Information: Spatial Data, Geographic Research, and New Social Practice. *Annals of the Association of American Geographers* **2012**, *102*, 571–590. https://doi.org/10.1080/00045608.2011.595657

[12] Barron, C.; Neis, P.; Zipf, A. A Comprehensive Framework for Intrinsic OpenStreetMap Quality Analysis. *Transactions in GIS* **2014**, *18*, 877–895. https://doi.org/10.1111/tgis.12073

[13] Crystal, D. *English as a Global Language*, 2nd ed.; Cambridge University Press: Cambridge, UK, 2003. https://doi.org/10.1017/CBO9780511486999

[14] Wedderburn, R.W.M. Quasi-Likelihood Functions, Generalized Linear Models, and the Gauss–Newton Method. *Biometrika* **1974**, *61*, 439–447. https://doi.org/10.1093/biomet/61.3.439

[15] Dobson, A.J.; Barnett, A.G. *An Introduction to Generalized Linear Models*, 3rd ed.; Chapman and Hall/CRC: Boca Raton, FL, USA, 2008.

[16] Lindén, A.; Mäntyniemi, S. Using the Negative Binomial Distribution to Model Overdispersion in Ecological Count Data. *Ecology* **2011**, *92*, 1414–1421. https://doi.org/10.1890/10-1831.1

[17] Russo, A.P. The "Vicious Circle" of Tourism Development in Heritage Cities. *Annals of Tourism Research* **2002**, *29*, 165–182. https://doi.org/10.1016/S0160-7383(01)00029-9

[18] Bandarin, F.; van Oers, R. *The Historic Urban Landscape: Managing Heritage in an Urban Century*; John Wiley & Sons: Chichester, UK, 2012. https://doi.org/10.1002/9781119968115

[19] Dodds, R.; Butler, R. The Phenomena of Overtourism: A Review. *International Journal of Tourism Cities* **2019**, *5*, 519–528. https://doi.org/10.1108/IJTC-06-2019-0090

[20] Milano, C.; Cheer, J.M.; Novelli, M., Eds. *Overtourism: Excesses, Discontents and Measures in Travel and Tourism*; CABI: Wallingford, UK, 2019.

---

## Tables

**Table 1.** Study sample by macro-region. Main analysis sample (cells with ≥5 named POIs). Multilingual and English visibility are POI-weighted city means averaged over cities; visitor POI density is the city mean of grid-level density; coverage is the mean OSM land-use mapped coverage (59 cities analysed).

| Macro-region | Cities | Countries | Grid cells | Named POIs | Multilingual visibility | English visibility | Visitor POI density (km⁻²) | Land-use coverage |
|---|---|---|---|---|---|---|---|---|
| Europe | 20 | 14 | 7,296 | 296,227 | 0.066 | 0.031 | 41.5 | 0.416 |
| Asia/MENA | 20 | 12 | 3,728 | 140,674 | 0.303 | 0.245 | 42.7 | 0.302 |
| Latin America | 19 | 10 | 3,996 | 115,652 | 0.033 | 0.025 | 33.0 | 0.312 |
| **All regions** | **59** | **36** | **15,020** | **552,553** | **0.136** | **0.101** | **39.2** | **0.344** |

**Table 2.** Variable definitions, data sources, and measurement.

| Variable | Definition | Source | Measurement |
|---|---|---|---|
| n_named_poi | Named POIs in cell | OSM `name` tag, Overpass API | Count per 500 m cell |
| Multilingual visibility (primary) | Share of named POIs with default name + distinct explicit language name, or ≥2 explicit language tags | OSM `name`, `name:<lang>`, `int_name` | $n_{multilingual}/n_{named}$; NA if no named POI |
| Multilingual visibility (strict) | Share of named POIs with ≥2 explicit language tags | OSM `name:<lang>` | Robustness definition (R1) |
| English visibility | Share of named POIs with English name | OSM `name:en`, `int_name` | Auxiliary outcome |
| Language richness / entropy | Distinct languages; Shannon entropy of language distribution | OSM `name:<lang>` | Auxiliary |
| Visitor POI density | Visitor-oriented POIs per km² (tourism, historic, food/drink, arts, marketplace, souvenir, travel, station, marina) | OSM POI tags | Main-analysis visitor measure |
| POI density | All named POIs per km² | OSM | Control |
| Land-use shares (10 classes) | Cell area share per OSM `landuse=*` class | OSM closed-way polygons | Shares (0–1); per-0.10 interpretation |
| Land-use coverage | Share of cell area with any mapped land-use polygon | OSM | Data-quality diagnostic; R3, R5 |
| Heritage distance | Euclidean distance, cell centroid → UNESCO heritage coordinate | UNESCO WHL + grid geometry | km; spline (df = 4) |
| City fixed effects | One indicator per city | — | Absorbs stable city-level differences |

**Table 3.** Grid-level descriptive statistics, main analysis sample (N = 15,020 cells with ≥5 named POIs; 59 cities).

| Variable | Mean | SD | p25 | Median | p75 | Min | Max |
|---|---|---|---|---|---|---|---|
| Named POIs per cell | 36.79 | 56.60 | 9 | 18 | 39 | 5 | 987 |
| Multilingual visibility (primary) | 0.106 | 0.191 | 0.000 | 0.013 | 0.122 | 0.000 | 1.000 |
| Multilingual visibility (strict) | 0.063 | 0.144 | 0.000 | 0.000 | 0.056 | 0.000 | 1.000 |
| English visibility | 0.071 | 0.147 | 0.000 | 0.000 | 0.071 | 0.000 | 1.000 |
| Language richness | 1.95 | 4.90 | 0 | 1 | 2 | 0 | 115 |
| Visitor POI density (km⁻²) | 44.19 | 112.51 | 4 | 12 | 36 | 0 | 2,416 |
| POI density (km⁻²) | 150.55 | 230.13 | 39.2 | 72.0 | 160.0 | 20.0 | 3,948 |
| Heritage distance (km) | 4.67 | 2.08 | 3.02 | 4.81 | 6.37 | 0.35 | 8.00 |
| Land-use coverage | 0.371 | 0.344 | 0.044 | 0.273 | 0.668 | 0.000 | 1.000 |
| Residential share | 0.221 | 0.310 | 0.000 | 0.040 | 0.367 | 0.000 | 1.000 |
| Commercial/retail share | 0.025 | 0.075 | 0.000 | 0.000 | 0.007 | 0.000 | 0.996 |

**Table 4.** Main model: quasi-binomial GLM of multilingual digital visibility (primary definition). N = 15,020 cells; 59 city fixed effects (coefficient range [−5.59, 0.82]); Pearson dispersion 4.178; natural cubic spline for heritage distance (joint Wald χ²(4) = 12,714.5, p < 0.001). Standard errors are quasi-likelihood (dispersion-scaled). Significance: *** p < 0.001, ** p < 0.01, * p < 0.05.

| Predictor | Estimate | Quasi SE | t | p |
|---|---|---|---|---|
| log1p(visitor POI density, km⁻²) | 0.0556 | 0.0144 | 3.87 | <0.001 *** |
| Commercial/retail share | 0.1872 | 0.0870 | 2.15 | 0.031 * |
| Residential share | 0.3064 | 0.0444 | 6.90 | <0.001 *** |
| Recreation/green share | −0.2980 | 0.5153 | −0.58 | 0.563 |
| Institutional share | −1.9003 | 0.6984 | −2.72 | 0.007 ** |
| Transportation share | 0.1505 | 0.3095 | 0.49 | 0.627 |
| log1p(POI density, km⁻²) | −0.0823 | 0.0204 | −4.04 | <0.001 *** |
| Heritage distance (spline, 4 terms) | — | — | — | <0.001 (joint) |

**Table 5.** Robustness suite. Cells report quasi-binomial coefficients with significance (*** p < 0.001, ** p < 0.01, * p < 0.05, · p < 0.1); the distance spline is jointly significant (p < 0.001) in all specifications.

| Specification | N | Cities | Visitor intensity | Commercial | Residential | Recreation | Institutional | Transportation | POI density |
|---|---|---|---|---|---|---|---|---|---|
| Main (POI ≥ 5) | 15,020 | 59 | 0.0556*** | 0.1872* | 0.3064*** | −0.2980 | −1.9003** | 0.1505 | −0.0823*** |
| R1 Strict definition | 15,020 | 59 | 0.1023*** | −0.3553** | −0.4847*** | 0.2670 | 0.1253 | 0.8690*** | −0.2789*** |
| R2 POI ≥ 10 | 11,120 | 58 | 0.0593*** | 0.1878* | 0.3129*** | −0.3062 | −1.9760** | 0.1708 | −0.0811*** |
| R2 POI ≥ 20 | 7,044 | 58 | 0.0302 | 0.0995 | 0.2924*** | −0.3821 | −2.0576* | −0.0493 | −0.0652* |
| R3 Coverage ≥ 0.25 | 7,746 | 57 | −0.0449* | −0.6642*** | −0.1631* | −0.9770· | −2.4582** | −0.4295 | 0.2028*** |
| R3 Coverage ≥ 0.50 | 5,354 | 54 | −0.0821** | −0.7330*** | −0.3281** | −0.8693 | −3.8484*** | −1.8757** | 0.3577*** |
| R4 Europe | 7,296 | 20 | −0.0104 | −0.1984 | 0.5112*** | −1.8258 | −3.9864** | −1.6545** | 0.2229*** |
| R4 Asia/MENA | 3,728 | 20 | 0.0004 | 0.5273** | −0.2720** | 1.2721* | 0.0334 | 1.8755*** | −0.2554*** |
| R4 Latin America | 3,996 | 19 | 0.4761*** | −2.1991** | 0.0436 | −4.9525 | −19.7847 | −3.2844 | −0.4353*** |
| R5 Two-part: share \| >0 | 7,708 | 59 | −0.0039 | 0.3239** | 0.3101*** | −0.0063 | −2.2612** | 0.4453 | −0.1824*** |
| R5 Drop low-coverage cities (15) | 13,480 | 44 | 0.0475** | 0.1981* | 0.3107*** | −0.2580 | −1.8944** | 0.2197 | −0.0742*** |

## Supplementary Materials

The following materials are available as separate files:

- **Table S1.** Per-city data quality (59 cities): grid counts, named POIs, explicit language-tag coverage, multilingual and English visibility, land-use coverage. File: `tables/TABLE_S1_city_quality.csv`.
- **Table S2.** City-level summary statistics (main sample and full grid set). File: `tables/TABLE_city_level_summary.csv`.
- **Table S3.** Interaction model (visitor intensity × commercial/retail share): interaction coefficient −0.0075 (quasi SE 0.0586, p = 0.899). File: `artifacts/model_interaction.txt`.
- **Table S4.** English-visibility auxiliary model: visitor intensity 0.2314***, residential −0.4635***, transportation 0.5767*, POI density −0.4292***; dispersion 2.719. File: `artifacts/model_english.txt`.
- **Figure S1.** Zero-inflation and land-use coverage diagnostics. File: `figures/fig_zero_inflation.png`, `figures/fig_landuse_coverage_dist.png`.
- **Data and code.** Full analysis dataset, build scripts, and analysis scripts. Files: `artifacts/analysis_sample.csv`, `artifacts/scripts/`.

## Figure Captions

**Figure 1.** (A) Study cities (n = 59) by macro-region. (B) Research workflow: UNESCO heritage coordinates → OSM extraction via Overpass API → 8 km study area and 500 m grid construction → grid-level measures → quasi-binomial GLM with city fixed effects and distance spline → robustness suite. Files: `figures/fig1a_sample_map.png`, `figures/fig1b_flow.png`.

**Figure 2.** (A) Predicted multilingual digital visibility by the dominant land-use type of the grid (city-size-weighted mean predictions with 95% confidence intervals from a city-level bootstrap, 1,000 draws). (B) Model-implied predicted visibility as the share of the focal land-use type increases from 0 to 0.6, with other covariates held at sample means and city fixed effects averaged by city size; shaded areas are 95% confidence intervals. Files: `figures/fig2_landuse.png`.

**Figure 3.** Predicted multilingual digital visibility by distance to the World Heritage core (natural cubic spline, df = 4; covariates at sample means; city fixed effects averaged by city size; shaded: 95% CI). Diamonds show observed POI-weighted band means for reference; the controlled gradient is steeper because near-core cells' higher visitor intensity and POI density are held constant. File: `figures/fig3_distance.png`.

**Figure 4.** Multilingual digital visibility in 500 m grids for six representative cities. Grey cells contain no named POI; the star marks the World Heritage core coordinate; the dashed circle marks the 8 km study radius. File: `figures/fig4_city_maps.png`.
