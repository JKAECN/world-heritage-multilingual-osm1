# 数据质量审计与描述统计报告

**项目**：Urban Land-Use Functions and Multilingual Digital Visibility in World Heritage Cities: A 59-City Grid-Based Analysis（Land 期刊）
**审计人**：洗澄明（数据工程师）
**数据来源**：`LAND_FINAL_RESULTS/FINAL_60cities_grid500m.csv`（OpenStreetMap，数据访问日期 2026-10-17）
**复现脚本**：`artifacts/scripts/01_audit_and_sample.py`、`02_descriptives_validation.py`

---

## 0. 术语重申

本报告所有指标衡量的是 **OpenStreetMap（OSM）中的数字语言可见性**（name:\<language\> 与 int_name 标签），**不是**实体街道标牌语言。主指标 multilingual_visibility_primary = 拥有"默认名 + 一个不同显式语言名"或"≥2 个显式语言标签"的有名 POI 占有名 POI 的比例。全文表格与论文写作必须保持这一表述。

---

## 1. 数据概览与数据契约（5 项检查）

| 检查项 | 结果 | 结论 |
|---|---|---|
| 形状 | 50,506 行 × **41 列**（任务书预估 42 列，实际 41） | 通过 |
| 城市数 | **59**（Puebla 因 landuse 下载失败被排除，见 ERROR_LOG.csv） | 通过 |
| 面板键重复 | grid_id 无重复（0 例） | 通过 |
| 每城网格数 | 58 城各 856；**Cordoba 858**（多出 2 个） | 基本通过，见 §2.5 |
| 缺失值 | 因变量族缺失率 54.78%（全部来自 n_named_poi=0 网格，设计内 NA）；poi_density_km2 / visitor_poi_density_km2 各 2 个 NA | 见 §2.5 |
| 坐标范围 | 遗产坐标经度 [-102.57, 135.84]、纬度 [-33.04, 59.44]，均为合法 UNESCO 遗产点；heritage_distance_km 最大 8.00 km（8 km 半径设计内） | 通过 |

**计数一致性**：所有网格满足 n_multilingual ≤ n_named_poi（违例 0）；n_named_poi=0 时可见性指标一律为 NA（27,666 网格），无反向错配；无可见性 >1 的网格。

---

## 2. 数据质量审计

### 2.1 城市层面（详见 TABLE_S1_city_quality.csv）

59 城全部进入质量表；Puebla 单列于 `TABLE_S1_city_quality_with_Puebla.csv` 并标注 landuse 缺失。城市间差异极大：

- **有名 POI 总量**：从 Quanzhou（65）到 Seoul（58,918），跨越三个数量级；
- **POI 加权多语可见性**：Salvador de Bahia 最低（0.0032），Macao 最高（0.655）；Istanbul（0.421）、Lijiang（0.290）、Ayutthaya（0.784，显式标签覆盖 0.835）为高值城市；
- **显式语言标签覆盖率**（n_language_tagged / n_named_poi）：欧洲城市普遍 <0.11（Vienna 0.027 最低），Macao 0.711、Lijiang 0.878、Ayutthaya 0.835 最高——数字多语化集中在非西方遗产城市，这是论文的核心描述性事实之一；
- **平均 landuse 覆盖度**：从 Vigan（0.004）、Ouro Preto（0.009）到 Warsaw（0.671）、Sighisoara（0.643）。

### 2.2 landuse_mapped_coverage 分布与稳健性阈值建议

**全量 50,506 网格**：高度双峰分布——40.68% 的网格覆盖度**恰为 0**（8 km 缓冲区内 OSM 无土地多边形），中位数仅 0.036，均值 0.246，q75=0.457，q90=0.849；无 >1 的值，4.20% 的网格 =1.0（封顶）。

| 分位 | q1 | q5 | q10 | q25 | q50 | q75 | q90 | q95 | q99 |
|---|---|---|---|---|---|---|---|---|---|
| 覆盖度 | 0 | 0 | 0 | 0 | 0.036 | 0.457 | 0.849 | 0.993 | 1.00 |

**在主分析样本（n_named_poi≥5）上**（分布右移，因低 POI 网格多在未绘制区）：

| 阈值 | 保留网格 | 占样本 | 覆盖城市数 | <20 网格的城市数 |
|---|---|---|---|---|
| ≥0.10 | 9,844 | 65.5% | 58/59 | — |
| **≥0.25** | **7,746** | **51.6%** | **57/59** | 16 |
| **≥0.50** | **5,354** | **35.6%** | **54/59** | 22 |

**建议**：
1. 研究设计提出的 **0.25 / 0.50 双阈值可行**，无需调整。≥0.25 保留一半以上样本和 57/59 城市，作为**主稳健性阈值**；≥0.50 保留 35.6%，作为**严格阈值**。
2. 但需注意**城市间覆盖度高度不均衡**：主样本中 26 城平均覆盖度 <0.25、11 城 <0.10（Pingyao 0.000、Zacatecas 0.012、Morelia 0.024、Vigan 0.027 等）。在 0.50 阈值下 Morelia、Zacatecas、Potosi、Pingyao、Vigan 贡献 ≈0 网格。建议在城市固定效应模型中该问题被吸收，但论文应报告"按城市平均覆盖度排序的低覆盖城市名单"，并在讨论中说明这些城市的 land_* 估计不可靠。
3. 覆盖度为 0 的网格**不应**从全量描述统计中剔除（它们是真实的 OSM 制图空白），但不应进入涉及 land_* 的回归解释。

### 2.3 零膨胀诊断（核心发现）

| 口径 | 全量 50,506 网格 | 主样本 15,020 网格 |
|---|---|---|
| n_named_poi = 0 | **27,666（54.78%）** | — |
| n_named_poi < 5 | 35,486（70.26%） | — |
| n_named_poi < 10 | 39,386（77.98%） | — |
| n_named_poi < 20 | 43,462（86.05%） | — |
| **multilingual_visibility_primary = 0** | — | **7,316（48.68%）** |
| multilingual_visibility_strict = 0 | — | 9,324（62.06%） |

**结论：零膨胀非常严重，且是双重的**——
- 第一重（分母零）：超过一半网格在 OSM 中没有任何有名 POI，主因变量结构性缺失（NA）。这是选择 n_named_poi≥5 门槛的核心理由；
- 第二重（分子零）：即便在 ≥5 POI 的网格中，仍有约 **49%** 的网格多语可见性为 0（严格定义下 62%）。
- 对建模的含义：因变量是**零膨胀的比例/计数**数据。R 流程采用的 quasibinomial GLM（cbind 成功数, 失败数) + 城市固定效应是正确的选择；建议顾因果在论文中明确报告样本内 48.7% 的零比例，并考虑零膨胀模型（如 zero-inflated / hurdle 二部模型）作为补充稳健性。median 可见性仅 0.013 而 mean 0.106，右偏严重，任何 OLS 规格都会受异方差与离群值困扰。

### 2.4 land_* 变量共线性

10 个 land_* 面积占比变量之间**最大 |相关系数| 仅 0.073**（land_industrial ~ land_transportation）。面积占比按多边形类型互斥划分，天然近正交，**不存在多重共线性问题**，VIF 无需担心。

### 2.5 其他完整性说明（次要问题）

1. **Cordoba 2 个退化网格**（cordoba_0857/0858）：grid_area_m2 = 0.0，无名 POI，密度字段为 NA。已被 n_named_poi≥5 门槛自动排除；建议在任何面积加权分析中显式剔除零面积网格。
2. **858 个网格（1.7%）的 land_* 加和 > landuse_mapped_coverage**（最大 +1.048）：集中于 Santo Domingo（123）、Tunis（82）、Lima（58）等城市，全部为正向差异。原因是 OSM 土地利用多边形存在重叠（不同类型各自计入），而 coverage 为并集面积且封顶于 1.0。均值差异仅 0.002，对回归影响可忽略；但论文如需报告"土地功能占比加总 = 覆盖度"应改为"约等于"。
3. **异常值**（|z|>4，仅标记未剔除）：n_named_poi 589 个、poi_density_km2 595 个、visitor_poi_density_km2 521 个、heritage_distance_km 0 个。高密度网格为真实的高强度市中心（如 Seoul、Macao），属数据生成过程而非录入错误，**保留**。visitor_poi_density_km2 最大 2,416/km²，winsorize 仅建议用于敏感性检验。

---

## 3. 分析样本定义

与既有 R 流程一致（并已验证其一致性，见 §5）：

| 步骤 | 操作 | 保留网格 | 剔除 |
|---|---|---|---|
| 0 | 原始数据 | 50,506 | — |
| 1 | 保留 n_named_poi ≥ 5（主因变量有定义且分母足够） | **15,020** | 35,486 |

- 主分析样本：`artifacts/analysis_sample.csv`（15,020 网格 × 41 列，59 城，每城 8–675 个网格，合计 552,553 个有名 POI、62,187 个多语 POI）。
- 全量网格保留用于描述统计与稳健性（如门槛敏感性：R 已有 ≥10 / ≥20 的结果）。
- 样本构建日志：`artifacts/sample_construction.json`。

---

## 4. 描述统计要点（完整表见 TABLE_3_descriptives.csv / TABLE_city_level_summary.csv）

**主分析样本（N=15,020）关键变量**：

| 变量 | mean | SD | median | IQR | min | max |
|---|---|---|---|---|---|---|
| n_named_poi | 36.79 | 56.60 | 18.00 | [9, 39] | 5 | 987 |
| multilingual_visibility_primary | 0.1063 | 0.1910 | 0.0129 | [0, 0.122] | 0 | 1 |
| multilingual_visibility_strict | 0.0630 | 0.1436 | 0.0000 | [0, 0.056] | 0 | 1 |
| english_visibility | 0.0707 | 0.1473 | 0.0000 | [0, 0.071] | 0 | 1 |
| language_richness | 1.949 | 4.896 | 1.000 | [0, 2] | 0 | 115 |
| visitor_poi_density_km2 | 44.19 | 112.51 | 12.00 | [4, 36] | 0 | 2,416 |
| heritage_distance_km | 4.666 | 2.077 | 4.809 | [3.02, 6.37] | 0.354 | 7.967 |
| landuse_mapped_coverage | 0.371 | 0.344 | 0.273 | [0.044, 0.668] | 0 | 1 |

TABLE_3_descriptives.csv 同时给出全量样本列（N=50,506；比例类变量 N=22,840）。城市层汇总（59 城）见 TABLE_city_level_summary.csv，含 POI 加权多语/英语可见性、游客 POI 密度、语言丰富度、覆盖度等。

---

## 5. 与 R 结果的交叉验证

| 验证对象 | 结果 | 结论 |
|---|---|---|
| CITY_DATA_QUALITY.csv（59 城，全量口径） | n_named_poi、显式标签覆盖、多语/英语可见性、覆盖度**全部逐城一致**（最大绝对差 ≤5×10⁻¹⁶，浮点精度） | ✅ 完全一致 |
| ANALYSIS_RESULTS/TABLE_city_summary.csv | n_grids、n_named_poi、POI 加权可见性、richness、entropy、覆盖度全部一致（≤5×10⁻¹⁶）；visitor_poi_density = 主样本简单均值（差 2.8×10⁻¹³）；确认 R 该表基于 **n_named_poi≥5 样本**（如 Vienna 675/856 网格） | ✅ 完全一致 |
| TABLE_distance_gradient.csv | 各距离带网格数合计 15,020 完全一致；可见性均值在 **POI 加权**口径下逐带一致（≤4×10⁻¹⁶）。我最初的未加权口径偏差达 0.052——已查明并纠正，R 用的是 POI 加权 | ✅ 一致（口径已澄清） |
| MODEL_1_main_multilingual_primary.txt | N=15,020 精确一致；Pearson 离散度 4.179 vs R 4.176；7 个核心协变量估计值全部吻合（log1p(visitor_density) 0.0559 vs 0.0540；commercial 0.1894 vs 0.1889；residential 0.3069 vs 0.3053；institutional -1.901 vs -1.933；log1p(poi_density) -0.0826 vs -0.0801……），符号、量级、显著性完全一致；微小差异来自 R ns() 与 patsy cr() 自然样条基函数差异 | ✅ 一致（估计可复现） |

**结论：Python 侧数字与既有 R 流水线完全对得上，无未解释差异。** 距离梯度表的口径澄清（POI 加权）应写入论文方法说明。

---

## 6. 给后续环节的提示

- **顾因果（模型）**：主样本 15,020 网格可用（analysis_sample.csv）；因变量零膨胀严重（48.7% 零），quasibinomial + 城市 FE 合理，建议补 hurdle/zero-inflated 稳健性；异方差必然存在（离散度 4.18），必须用准似然或聚类 SE。
- **严复核（稳健性）**：≥10 / ≥20 门槛已有 R 结果可对照；landuse 覆盖度 0.25/0.50 阈值样本量已验证（7,746 / 5,354）；建议补一个"剔除 11 个平均覆盖度 <0.10 城市"的城市层稳健性。
- **文锦成（写作）**：Table 3 与城市层表已备好；所有涉及指标的表述必须使用"OSM 数字语言可见性"口径；论文须报告 54.8% 网格无有名 POI 这一抽样现实。
- **数据使用禁区**：`GRID_multilingual_service_tourism_mismatch.csv` 与 `GRID_top10pct_language_service_gap.csv` 及其衍生变量（mismatch / z-score 差）已确认未在本次审计与全部交付物中使用，保留给第二篇 Applied Geography 论文。

---

## 附：交付物清单

- `reports/data_audit_report.md`（本文件）
- `tables/TABLE_S1_city_quality.csv`、`TABLE_S1_city_quality_with_Puebla.csv`（含 Puebla 标注行）
- `tables/TABLE_3_descriptives.csv`（网格层，主样本 + 全量双口径）
- `tables/TABLE_city_level_summary.csv`（59 城汇总，双口径）
- `artifacts/analysis_sample.csv`（15,020 网格主分析样本）
- `artifacts/sample_construction.json`（样本构建日志 + 数据契约 + 一致性检查）
- `artifacts/audit_stats.json`、`artifacts/validation_report.json`（审计统计与验证明细）
- `artifacts/scripts/01_audit_and_sample.py`、`02_descriptives_validation.py`（可复现）
- `figures/fig_landuse_coverage_dist.png`、`fig_zero_inflation.png`、`fig_land_corr_heatmap.png`
