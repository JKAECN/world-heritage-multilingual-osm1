# 文献综述报告：城市土地功能与多语数字可见性

**论文题目**：Urban Land-Use Functions and Multilingual Digital Visibility in World Heritage Cities: A 59-City Grid-Based Analysis
**执行人**：搜文献（lit-reviewer）
**日期**：2026-10-18
**核验方式**：每条文献均经 WebSearch 多源交叉核验（出版社官网、期刊页面、机构知识库、OpenAlex/Ethnos/ERIC 记录等），确认作者、年份、标题、期刊/出版社、卷期页；不确定的条目不进入参考文献表。

---

## 一、检索与核验概要

围绕任务指定的 8 个方向逐条核验，**最终收录 27 条真实文献**（目标 15–25 条，因覆盖面完整略超）。所有条目均给出可溯源信息；能查到 DOI 的 20 条全部给出 DOI，未确认 DOI 的 7 条（专著/章节）给出 ISBN。BibTeX 已写入 `artifacts/references.bib`，可直接 `\bibliography` 导入。

**一处重要勘误**：任务描述中的 "Lou 2016 (Annals of the AAG)" 不准确。经核验，DOI 10.1080/00045600701734042 实为 Brown, Knopp et al. (2008) "Queering the Map"（Annals 98(1): 40–58），并非 Lou 的论文。Jackie Jia Lou 的 2016 年代表作是专著 *The Linguistic Landscape of Chinatown: A Sociolinguistic Ethnography*（Multilingual Matters，ISBN 9781783095629），已按专著收录。若写作组确实需要一篇 Annals AAG 的语言景观地理论文，建议另行确认，本报告不放入未核验条目。

---

## 二、按主题分组的文献清单

### 主题 1：语言景观理论奠基（6 条）

1. **Landry, R., & Bourhis, R. Y. (1997). Linguistic Landscape and Ethnolinguistic Vitality: An Empirical Study. *Journal of Language and Social Psychology*, 16(1), 23–49.** DOI: 10.1177/0261927X970161002
   - 核心观点：语言景观指"公共道路标识、广告牌、街名、地名、商业招牌与公共建筑标识共同构成特定地域的语言面貌"，兼具信息功能与符号功能，是语言群体相对权力与地位的标志。
   - 拟引用位置：**引言第 1 段**（给出语言景观的奠基定义，作为本研究"多语数字可见性"的概念母体）；**文献综述 2.1 节**。

2. **Gorter, D. (2006). Introduction: The Study of the Linguistic Landscape as a New Approach to Multilingualism. *International Journal of Multilingualism*, 3(1), 1–6.** DOI: 10.1080/14790710608668382
   - 核心观点：正式提出将语言景观作为研究多语现象的新路径，强调全球化背景下英语的扩散与身份认同的符号表达。
   - 拟引用位置：**文献综述 2.1 节**（论证语言景观从描述性工具走向系统研究范式）；引言第 2 段。

3. **Ben-Rafael, E., Shohamy, E., Hasan Amara, M., & Trumper-Hecht, N. (2006). Linguistic Landscape as Symbolic Construction of the Public Space: The Case of Israel. *International Journal of Multilingualism*, 3(1), 7–30.** DOI: 10.1080/14790710608668383
   - 核心观点：语言景观是公共空间的符号建构，多语格局并非真实语言名录的镜像，而是由"理性考量、自我呈现、权力关系"三因素驱动的选择结果。
   - 拟引用位置：**文献综述 2.1 节**（解释为何可见的语言 ≠ 存在的语言，为"数字可见性"区别于"人口语言构成"提供理论依据）；**讨论 5.x**。

4. **Scollon, R., & Scollon, S. W. (2003). *Discourses in Place: Language in the Material World*. London: Routledge.** ISBN 9780415290487; DOI: 10.4324/9780203422724
   - 核心观点：提出地理符号学（geosemiotics）框架——code preference、inscription、emplacement 三维度解读物质世界中公共文本的意义。
   - 拟引用位置：**文献综述 2.1 节**（方法论传统）；**方法 3.x**（说明本研究从"招牌物理符号"转向"地图数字符号"的谱系）。

5. **Backhaus, P. (2007). *Linguistic Landscapes: A Comparative Study of Urban Multilingualism in Tokyo*. Clevedon: Multilingual Matters.** ISBN 9781853599460
   - 核心观点：对东京 28 个调查区 2444 块招牌的系统量化，证明多语标识在城市内部呈显著空间分异，且官方/非官方标识遵循不同逻辑。
   - 拟引用位置：**引言第 2 段**（量化语言景观的既有最佳实践——但是单城市、小样本）；**文献综述 2.2 节**；**讨论 5.x**（本研究 59 城 × 网格 对其"单城市"局限的回应）。

6. **Lou, J. J. (2016). *The Linguistic Landscape of Chinatown: A Sociolinguistic Ethnography*. Bristol: Multilingual Matters.** ISBN 9781783095629
   - 核心观点：华盛顿唐人街的语言景观民族志，揭示城市更新与绅士化如何通过标识重塑社区的符号边界与"本真性"冲突。
   - 拟引用位置：**文献综述 2.2 节**（定性/民族志传统，与本文大样本定量设计形成对照）；**讨论 5.x**（土地功能变化—语言可见性变化的社会机制）。

### 主题 2：旅游语境中的语言景观与多语现象（3 条）

7. **Shohamy, E., & Gorter, D. (Eds.). (2009). *Linguistic Landscape: Expanding the Scenery*. New York: Routledge.** ISBN 9780415988735
   - 核心观点：语言景观研究的扩展卷，含 Kallen"旅游与爱尔兰语言景观中的表征"、Barni & Bagna"语言景观的制图技术"等关键章节，将研究视野推向旅游、身份与政策维度。
   - 拟引用位置：**文献综述 2.2 节**（旅游语境语言景观的理论入口）；**方法 3.x**（制图方法论先例）。

8. **Jaworski, A., & Thurlow, C. (Eds.). (2010). *Semiotic Landscapes: Language, Image, Space*. London: Continuum.** ISBN 9781847061829
   - 核心观点：将符号景观拓展到旅游、精英流动与全球资本主义语境，论证空间本身是符号资源，"沉默"也是语言策略。
   - 拟引用位置：**文献综述 2.2 节**（旅游符号学视角）；**讨论 5.x**（遗产城市"为游客表演"的多语可见性）。

9. **Crystal, D. (2003). *English as a Global Language* (2nd ed.). Cambridge: Cambridge University Press.** DOI: 10.1017/CBO9780511486999
   - 核心观点：英语成为全球通用语的历史与结构性原因，尤其支配国际旅行、广告与媒体领域。
   - 拟引用位置：**引言第 2 段**（预期遗产城市英语标签占主导的理论依据）；**结果/讨论**（英语可见性的梯度解释）。

### 主题 3：数字地理学 / VGI / 平台可见性（6 条）

10. **Goodchild, M. F. (2007). Citizens as Sensors: The World of Volunteered Geography. *GeoJournal*, 69(4), 211–221.** DOI: 10.1007/s10708-007-9111-y
    - 核心观点：VGI 概念奠基——公民作为传感器自发生产地理信息，构成对官方测绘的补充与挑战。
    - 拟引用位置：**引言第 3 段**（OSM 作为数据源的理论定位）；**文献综述 2.3 节**。

11. **Haklay, M., & Weber, P. (2008). OpenStreetMap: User-Generated Street Maps. *IEEE Pervasive Computing*, 7(4), 12–18.** DOI: 10.1109/MPRV.2008.80
    - 核心观点：OSM 是遵循 Wikipedia 同行生产模式的知识共同体，全球志愿者协作编辑自由地图数据。
    - 拟引用位置：**文献综述 2.3 节**；**方法 3.x（数据）**（OSM 项目性质说明）。

12. **Elwood, S., Goodchild, M. F., & Sui, D. Z. (2012). Researching Volunteered Geographic Information: Spatial Data, Geographic Research, and New Social Practice. *Annals of the Association of American Geographers*, 102(3), 571–590.** DOI: 10.1080/00045608.2011.595657
    - 核心观点：VGI 是地理信息生产与共享的范式转变，需要新的综合方法与社会政治批判视角。
    - 拟引用位置：**方法 3.x（数据与质量）**；**局限与展望**（VGI 偏差问题）。

13. **Barron, C., Neis, P., & Zipf, A. (2014). A Comprehensive Framework for Intrinsic OpenStreetMap Quality Analysis. *Transactions in GIS*, 18(6), 877–895.** DOI: 10.1111/tgis.12073
    - 核心观点：提出 25+ 个仅依赖数据历史的内在质量指标，无需参考数据集即可评估 OSM 属性（如 name 标签）的完整性与可信度。
    - 拟引用位置：**方法 3.x（数据质量审计）**；**局限**（name 标签覆盖率的城市间差异及其对指标的解释）。

14. **Graham, M., & Zook, M. (2013). Augmented Realities and Uneven Geographies: Exploring the Geolinguistic Contours of the Web. *Environment and Planning A*, 45(1), 77–99.** DOI: 10.1068/a44674
    - 核心观点：对 Google Maps 索引内容的全球分析揭示"地缘语言轮廓"——数字增强的地方在语言维度上分布极不平等，影响地方被想象与体验的方式。
    - 拟引用位置：**引言第 3 段**（最直接的前驱研究，本文将其从"全球/国家间"推进到"城市内部网格级"）；**文献综述 2.3 节**；**讨论 5.x**。

15. **Luque-Ayala, A., & Maia, F. N. (2019). Digital Territories: Google Maps as a Political Technique in the Re-making of Urban Informality. *Environment and Planning D: Society and Space*, 37(3), 449–467.** DOI: 10.1177/0263775818766069
    - 核心观点：数字制图是政治技术，不仅"再现"空间，更通过计算逻辑生产可见性、合法性与领土化不平等。
    - 拟引用位置：**引言第 3 段**（平台表征的生产性）；**讨论 5.x**（OSM 多语标签作为平台化知识生产的后果）。

### 主题 4：POI 与土地利用功能推断（2 条）

16. **Yuan, J., Zheng, Y., & Xie, X. (2012). Discovering Regions of Different Functions in a City Using Human Mobility and POIs. *Proceedings of KDD '12*, 186–194.** DOI: 10.1145/2339530.2339561
    - 核心观点：DRoF 框架用 POI 类别与人类移动推断城市功能区分布，证明 POI 类别结构是土地功能的最常用众源代理。
    - 拟引用位置：**文献综述 2.4 节**；**方法 3.x（功能变量构建）**（以 POI 类别结构测度商业/居住/休闲/机构/交通功能强度的依据）。

17. **Andrade, R., Alves, A., & Bento, C. (2020). POI Mining for Land Use Classification: A Case Study. *ISPRS International Journal of Geo-Information*, 9(9), 493.** DOI: 10.3390/ijgi9090493
    - 核心观点：POI 数据经特征挖掘可达到 90%+ 精度的土地利用分类，是昂贵 LULC 制图的可扩展替代（同属 MDPI 期刊，与本刊读者群一致）。
    - 拟引用位置：**文献综述 2.4 节**；**方法 3.x**（土地功能测量的方法先例与精度参照）。

### 主题 5：世界遗产城市、过度旅游与核心-边缘结构（4 条）

18. **Russo, A. P. (2002). The "Vicious Circle" of Tourism Development in Heritage Cities. *Annals of Tourism Research*, 29(1), 165–182.** DOI: 10.1016/S0160-7383(01)00029-9
    - 核心观点：遗产城市存在旅游恶性循环——旅游对核心区空间的集约占用挤出居住与其他功能，推动核心-边缘功能分化（威尼斯案例）。
    - 拟引用位置：**引言第 4 段**（遗产城市核心-边缘结构的旅游机制）；**文献综述 2.5 节**；**假设 H4**（到遗产核心距离）的理论来源。

19. **Bandarin, F., & van Oers, R. (2012). *The Historic Urban Landscape: Managing Heritage in an Urban Century*. Chichester: Wiley.** DOI: 10.1002/9781119968115
    - 核心观点：UNESCO HUL 方法权威阐述——遗产价值层叠于城市整体功能层之中，历史核心区与日常城市空间不可分割。
    - 拟引用位置：**文献综述 2.5 节**（遗产城市的整体性视角）；**讨论 5.x**（为何"到核心距离"应预测城市内部的多语可见性格局）。

20. **Dodds, R., & Butler, R. (2019). The Phenomena of Overtourism: A Review. *International Journal of Tourism Cities*, 5(4), 519–528.** DOI: 10.1108/IJTC-06-2019-0090
    - 核心观点：过度旅游的系统综述——游客压力在城市尤其是遗产城市中的成因、后果与政策缓释。
    - 拟引用位置：**引言第 4 段**；**讨论 5.x**（旅游导向功能强度与多语可见性关系的政策含义）。

21. **Milano, C., Cheer, J. M., & Novelli, M. (Eds.). (2019). *Overtourism: Excesses, Discontents and Measures in Travel and Tourism*. Wallingford: CABI.** ISBN 9781786399823
    - 核心观点：威尼斯、京都、阿姆斯特丹等案例显示旅游化（touristification）系统性改变局部功能与商业构成，催生面向游客的多语标识需求。
    - 拟引用位置：**文献综述 2.5 节**；**假设 H2**（旅游导向功能 → 多语可见性）的依据。

### 主题 6：网格化空间分析与 MAUP（3 条）

22. **Openshaw, S. (1984). *The Modifiable Areal Unit Problem* (Concepts and Techniques in Modern Geography No. 38). Norwich: Geo Books.** ISBN 0860941345
    - 核心观点：MAUP 原始文献——聚合单元任意可修改，统计结果随单元形状/尺度而变，空间分析必须报告单元敏感性。
    - 拟引用位置：**方法 3.x（网格设计）**；**稳健性**（500m 主网格 + 其他尺度的敏感性检验的依据）。

23. **Jelinski, D. E., & Wu, J. (1996). The Modifiable Areal Unit Problem and Implications for Landscape Ecology. *Landscape Ecology*, 11(3), 129–140.** DOI: 10.1007/BF02447512
    - 核心观点：系统分解 MAUP 的尺度效应与分区效应，并示范其对空间分析结论的影响。
    - 拟引用位置：**方法 3.x**；**稳健性**（与 Openshaw 1984 二选一或同引）。

24. **Lloyd, C. T., Sorichetta, A., & Tatem, A. J. (2017). High Resolution Global Gridded Data for Use in Population Studies. *Scientific Data*, 4, 170001.** DOI: 10.1038/sdata.2017.11
    - 核心观点：WorldPop 全球高分辨率格网数据范式——格网是当代精细人口与城市研究的基本空间单元。
    - 拟引用位置：**方法 3.x（网格化设计）**（500m 网格作为分析单元的学科先例）。

### 主题 7：广义线性模型 / 准二项 / 过度离散（3 条）

25. **Wedderburn, R. W. M. (1974). Quasi-Likelihood Functions, Generalized Linear Models, and the Gauss–Newton Method. *Biometrika*, 61(3), 439–447.** DOI: 10.1093/biomet/61.3.439
    - 核心观点：准似然只需指定均值-方差关系即可估计，是准二项（quasibinomial）GLM 处理过度离散的理论基础。
    - 拟引用位置：**方法 3.x（统计模型）**（quasibinomial GLM 的理论出处）。

26. **Dobson, A. J., & Barnett, A. G. (2008). *An Introduction to Generalized Linear Models* (3rd ed.). Boca Raton: Chapman & Hall/CRC.** ISBN 9781584889502
    - 核心观点：GLM 标准教材——logit 连接、二项族、过度离散诊断与模型检验的规范表述。
    - 拟引用位置：**方法 3.x（统计模型）**。

27. **Lindén, A., & Mäntyniemi, S. (2011). Using the Negative Binomial Distribution to Model Overdispersion in Ecological Count Data. *Ecology*, 92(7), 1414–1421.** DOI: 10.1890/10-1831.1
    - 核心观点：系统比较计数数据过度离散的处理策略（准似然/负二项等），均值-方差设定的选择直接影响推断。
    - 拟引用位置：**方法 3.x** + **稳健性**（过度离散处理方式的对比依据；若改用负二项或观测水平聚合可引此文）。

---

## 三、研究缺口陈述（本论文的新意）

综合上述 27 条文献，可以识别出四个层面的缺口，构成本文的贡献定位：

**缺口 1｜对象缺口：从"招牌语言"到"数字地图语言标签"。**
既有语言景观研究（Landry & Bourhis 1997; Ben-Rafael et al. 2006; Backhaus 2007; Lou 2016）以实体招牌为对象，依赖田野拍摄与人工编码，样本通常限于单城市数十个街区（如东京 28 区）。本研究首次将 OSM `name:language` 标签作为"多语数字可见性"的系统测量，把语言景观从街头符号学推进到平台制图的知识生产过程（Goodchild 2007; Haklay & Weber 2008; Elwood et al. 2012）。

**缺口 2｜尺度缺口：从城市间比较到城市内部网格。**
Graham & Zook (2013) 揭示了 Google Maps 内容的"地缘语言轮廓"，但其分析单位是全球/城市间；语言景观的城市内部分异研究（Backhaus 2007）则受限于小样本。本文在 59 个世界遗产城市各 8 km 半径、500 m 网格上（约每城 800 格）同时测量多语可见性与土地功能强度，首次实现"城市内部、跨城市可重复"的网格级分析，并用 MAUP 框架（Openshaw 1984; Jelinski & Wu 1996）明示单元敏感性。

**缺口 3｜理论缺口：多语可见性的"城市功能解释"缺失。**
语言景观文献解释了多语格局的符号与权力机制（Ben-Rafael et al. 2006; Jaworski & Thurlow 2010），POI 文献解释了土地利用功能的推断（Yuan et al. 2012; Andrade et al. 2020），遗产旅游文献解释了核心-边缘功能分化（Russo 2002; Dodds & Butler 2019），但三条文献线从未交汇：**没有研究系统检验过城市内部土地功能（商业/居住/休闲/机构/交通）、旅游导向功能强度与到遗产核心距离对多语数字可见性的联合解释力**。本文以准二项 GLM + 城市固定效应 + 距离样条（Wedderburn 1974; Dobson & Barnett 2008）填补这一空白。

**缺口 4｜数据缺口：遗产城市的全球大样本证据缺乏。**
既有遗产城市研究以威尼斯、阿姆斯特丹等单案例为主（Russo 2002; Milano et al. 2019）。本文覆盖 59 个世界遗产城市的全球样本，为 HUL 方法（Bandarin & van Oers 2012）提供了一个可复制的城市内部结构量化工具。

---

## 四、建议的引言论证逻辑（3–5 句）

1. 语言景观——公共空间中语言的可见与缺席——是社区权力、身份与商业逻辑的符号缩影（Landry & Bourhis 1997; Ben-Rafael et al. 2006）；在旅游语境中，多语标识更是面向全球游客的市场策略（Backhaus 2007; Crystal 2003; Jaworski & Thurlow 2010）。
2. 然而，随着城市日益通过数字平台被搜索、导航与消费，地方的"可见性"越来越由众源地图数据生产：OSM 的 `name:language` 标签记录了志愿者为世界遗产地标注的多语名称，构成一种新型的"数字语言景观"（Goodchild 2007; Graham & Zook 2013; Luque-Ayala & Maia 2019）。
3. 既有研究或停留于单城市小样本（Backhaus 2007; Lou 2016），或停留于全球尺度的语言不平等（Graham & Zook 2013），尚无研究在统一的网格框架内检验：**城市内部土地功能与旅游压力如何塑造多语数字可见性的空间格局**（Yuan et al. 2012; Russo 2002）。
4. 本文利用 59 个世界遗产城市 8 km 半径内 500 m 网格的 OSM 数据，以准二项 GLM（Wedderburn 1974）估计土地功能、旅游功能强度与到遗产核心距离对多语数字可见性的影响，为数字时代的遗产城市语言生态提供首个全球网格级证据。

---

## 五、引用统计与质量说明

- **总条目**：27 条（期刊论文 15、会议论文 1、专著/编著 11）
- **DOI 覆盖**：20/27（专著无 DOI 者均给 ISBN）
- **年份分布**：1974, 1984, 1996, 1997, 2002, 2003, 2006×2, 2007×2, 2008×2, 2009, 2010, 2011, 2012×3, 2013, 2014, 2016, 2017, 2019×3, 2020——经典（1974–2003，8 条）与前沿（2006–2020，19 条）兼顾
- **主题覆盖**：语言景观理论（5）、旅游多语（3）、VGI/OSM（5）、数字可见性/平台地理（2，并入 VGI 组计）、POI-土地利用（2）、遗产城市与过度旅游（4）、网格与 MAUP（3）、GLM 方法（3）——任务全部 8 个方向均覆盖
- **期刊档次**：覆盖 *Annals of the AAG*、*Annals of Tourism Research*、*Biometrika*、*Ecology*、*Landscape Ecology*、*Environment and Planning A/D*、*GeoJournal*、*Transactions in GIS*、*Scientific Data*、*IEEE Pervasive Computing* 及 KDD，另含 MDPI *IJGI*（与目标期刊 Land 同社）
- **核验状态**：全部 27 条经 WebSearch 实证核验，无编造条目；唯一对任务描述的修正为 Lou 2016 的出版类型（见第一节勘误）

---

## 六、给写作组的引用提示

- **不要引用**任务描述中提到的 "Lou 2016, Annals of the AAG"——该组合不存在；请用本报告收录的 Lou (2016) 专著。
- Overpass API 无独立的学术文献可引，建议在方法部分以软件引用格式引用 OpenStreetMap 项目本身（如 "© OpenStreetMap contributors, ODbL"）及 Overpass API 文档。
- 若审稿人要求补充"英语作为旅游通用语"的经验证据，可优先使用 Crystal (2003) + Backhaus (2007) 的组合，无需新增检索。
- 若模型部分从准二项改为负二项或 beta 回归，请补引 Lindén & Mäntyniemi (2011) 之外的新文献并重新核验。
